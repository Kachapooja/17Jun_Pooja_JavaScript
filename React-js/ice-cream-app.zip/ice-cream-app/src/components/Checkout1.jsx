import React,{useState,useEffect,useRef} from 'react'
import axios from 'axios'
import {useNavigate,Link} from 'react-router-dom';
import Header from './Header.jsx'
import Navbar from './Navbar.jsx'
import Footer from './Footer.jsx'
import Swal from 'sweetalert2';
export default function Checkout1() {
// destructuring od data to fetch all data 
const[data,setData]=useState([]);
const Navigate=useNavigate();
// subtotal of totals products
// orders successfully added
// destructuring od data to fetch all data 
const name=useRef("");
const email=useRef("");
const phone=useRef("");
const address=useRef("");
const productimage=useRef("");
const productname=useRef("");
const qty=useRef("");
const newprice=useRef();
const subtotal=useRef();
const descriptions=useRef("");

// const total=newprice*subtotal;

useEffect(()=>{
//get api to fetch data using axios.get() 
axios.get(`http://localhost:4000/view-cart`).then((response)=>{
setData(response.data);
newprice.current.value=response.data.newprice;
subtotal.current.value=response.data.subtotal;
// total.current.value=response.data.total;

});
// pass messages
Navigate('/checkout');
},[]); //renders one times 



// after addtocart product added in cart
const AddOrdersFormHandeler=(e)=>{
  e.preventDefault();
  var insert={
    name:name.current.value,
    email:email.current.value,
    phone:phone.current.value,
    address:address.current.value,
    productimage:productimage.current.value,
    productname:productname.current.value,
    newprice:newprice.current.value,
    qty:qty.current.value,
    descriptions:descriptions.current.value,
    subtotal:subtotal.current.value,   
  }
    // call api to add in cart
    axios.post(`http://localhost:4000/orders`,insert).then(()=>{

    Swal.fire({
      title: "Wow",
      text: "Thanks for Orders Now we will Delivered it on Your Orders Address",
      icon: "success"
    });
    Navigate('/order-sucess');

    });

}


return (
<>
<Header />
<Navbar />

<form onSubmit={AddOrdersFormHandeler}>
<div className="container-fluid py-5">
<div className="container card py-5">
<div className='row'>
<div className='col-md-5'>
<h5>Fill All (*) Required customers details for Orders</h5>

<div className="form">
<div className="form-group">
<input
type="text" name="name" ref={name}
className="p-4 form-control"
id="name" 
placeholder="Your Name"
required="required" 
data-validation-required-message="Please enter your name"
/>
<p className="help-block text-danger" />
</div>
<div className="form-group">
<input
type="email" name="email" ref={email}
className="form-control p-4"
id="email"
placeholder="Your Email"
required="required"
data-validation-required-message="Please enter your email"
/>
<p className="help-block text-danger" />
</div>
</div>
<div className="control-group">
<input
type="text" name="phone" ref={phone} 
className="form-control p-4"
id="subject"
placeholder="Phone"
required="required"
data-validation-required-message="Please enter a subject"
/>
<p className="help-block text-danger" />
</div>


<div className="control-group">
<textarea ref={address}
className="form-control p-4"
rows={6}
id="message" name="message" 
placeholder="Address"
required="required"
data-validation-required-message="Please enter your message"
defaultValue={""}
/>
<p className="help-block text-danger" />
</div>
<div>

</div>

</div> 
<div className='col-md-7'>
<div className='card-header'><h2>Order Summary</h2></div>
<div className='card-body'>

<table className='table table-responsive' width="90%">
<thead>
<tr>
<th>Photo</th>
<th>Name</th>
<th>OfferPrice</th>
<th>qty</th>
<th>Subtotal</th>
</tr>
</thead>

{data && data.map((items)=>{
return (
<>
<tbody>
<tr>
{/* <input type='hidden' ref={productimage} /> */}
<td><img src={items.productimage} alt='cartphoto' className='img-fluid w-50' /></td>
<td><input type='text' ref={productname} value={items.productname} readOnly style={{border:"none",width:"85px"}} /></td>
<td> <input type='text' ref={newprice} value={items.newprice} readOnly style={{border:"none",width:"85px"}} /></td>
<td><input type='text' ref={qty} value={items.qty} readOnly style={{border:"none",width:"35px"}} /></td>
<td> <input type='text' ref={subtotal} value={items.subtotal}  readOnly style={{border:"none",width:"85px"}} /></td>
</tr>  
</tbody>

</>
)
})}

<tr>
<td colSpan="6" align='right'>  
<input type='submit' value="Order Now" className='btn btn-sm bg-dark text-white w-75 float-end' />
</td>
</tr>

{/* <tr>
<td colSpan="6">
<h3 className='bg-dark text-white w-75 p-2 float-end'>Subtotal of Products Rs. {} </h3>
</td>
</tr> */}
</table>



</div>
</div>
</div>    
</div>

</div>
</form>
<Footer />
</>

)
}
